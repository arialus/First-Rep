export cosnt GoogleAPIKey = "AIzaSyBlay37AbsRq1RDiGhsJpZwdTyWEmBLVd8";

export const another key = "AIzaSyD_CPzHN47lpN6NQX9aldSUhBTQ97NJdg0"